<?php $__env->startSection('title', 'Ver película'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-4">
            <img src="<?php echo e($pelicula->poster); ?>" alt="">
        </div>
        <div class="col-sm-8">
            <h3><?php echo e($pelicula->title); ?></h3>
            <h5>Año: <?php echo e($pelicula->year); ?></h5>
            <h5>Director: <?php echo e($pelicula->director); ?></h5>
            <p><strong>Resumen: </strong><?php echo e($pelicula->synopsis); ?></p>
            <spam><strong>Estado: </strong></spam>
            <?php if($pelicula->rented): ?>
            <form action="<?php echo e(action([App\Http\Controllers\CatalogController::class, 'putReturn'], ['id' => $pelicula->id])); ?>" 
                method="POST" style="display:inline">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger" style="display:inline">
                    Devolver película
                </button>
            </form>
            <?php else: ?>
            <form action="<?php echo e(action([App\Http\Controllers\CatalogController::class, 'putRent'], ['id' => $pelicula->id])); ?>" 
                method="POST" style="display:inline">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary" style="display:inline">
                    Alquilar película
                </button>
            </form>                
            <?php endif; ?>
            <a class="btn btn-warning" href="/catalog/edit/<?php echo e($pelicula->id); ?>">Editar pelicula</a>
            <a type="button" class="btn btn-dark" href="/catalog">Volver al listado</a>
            <form action="<?php echo e(action([App\Http\Controllers\CatalogController::class, 'deleteMovie'], ['id' => $pelicula->id])); ?>" 
                method="POST" style="display:inline">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger" style="display:inline">
                    Eliminar pelicula
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/carlos/my_example_app/resources/views/catalog/show.blade.php ENDPATH**/ ?>